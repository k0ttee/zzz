#!/bin/bash

cores=$(sysctl -n hw.physicalcpu)
threads=$(sysctl -n hw.logicalcpu)
stressess=$(pgrep yes | wc -l | awk '{$1=$1;print}')

echo "ЯДЕР........${cores}"
echo "ПОТОКОВ.....${threads}"
echo "СТРЕССОВ....${stressess}"

if [ $stressess -lt $threads ];
then
	stressess=$((stressess + 1))
	echo "ДОБАВЛЯЮ 1 СТРЕСС"
	echo "СТРЕССОВ........${stressess}"
	yes > /dev/null 2>&1 &
else
	echo "УЖЕ ЗАПУЩЕНЫ СТРЕССЫ НА ВСЕ ПОТОКИ"
fi

# грохнуть все тесты можно командой
# killall -9 yes