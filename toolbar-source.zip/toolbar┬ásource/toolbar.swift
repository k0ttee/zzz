import AppKit
import Foundation

let app = NSApplication.shared
let statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)







// функция получения температуры
// /usr/local/Cellar/osx-cpu-temp/1.1.0/bin/osx-cpu-temp

func executeExternalProgram() -> String? {
    let task = Process(), pipe = Pipe()
    task.launchPath = "/Applications/ToolBar.app/Contents/MacOS/osx-cpu-temp"
    task.standardOutput = pipe
    task.launch()
    
    return String(data: pipe.fileHandleForReading.readDataToEndOfFile(), encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines)
}












// обновление значения каждые N целых N десятых секунд

let updateInterval: TimeInterval = 1.4

let timer = Timer.scheduledTimer(withTimeInterval: updateInterval, repeats: true) { _ in
    if let result = executeExternalProgram() {
        statusItem.button?.title = result
    }
}

RunLoop.current.add(timer, forMode: .common)


















// расширения

extension NSApplication {
    func runTask(_ appName: String, _ arg: String = "") {
        let task = Process()
        task.executableURL = URL(fileURLWithPath: "/usr/bin/open")
        task.arguments = arg.isEmpty ? [appName] : [arg, appName]
        try? task.run()
    }
}





// интерфейсы

let menu = NSMenu()
let quitItem = NSMenuItem(title: "Exit", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "")
menu.addItem(quitItem)
statusItem.menu = menu





//концовка

app.setActivationPolicy(.prohibited)
app.run()
